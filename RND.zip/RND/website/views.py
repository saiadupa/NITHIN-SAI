import mimetypes
import os
from unicodedata import name
from flask import Blueprint, appcontext_popped, redirect, render_template, request, flash, jsonify, url_for
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from .models import Note
from . import db
import json
views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        teacher = request.form['teacher']
        journal = request.form['journal']
        year = request.form['year']
        link = request.form['link']
        index = request.form['index']
        file = request.files['file']

        filename = secure_filename(file.filename)

        if file.filename != '':
            file.save(os.path.join('C:\\Users\\Sai\\OneDrive\\Desktop\\RND\\website\\static\\files',filename))
            fil = file.filename
        else:
            fil = 'No file'
       

        new_note = Note(title=title, author=author, department_teacher=teacher,journal=journal,publication_year=year,link=link,h_index=index,file=fil, user_id=current_user.id)

        db.session.add(new_note)
        db.session.commit()
        flash('Note added!', category='success')
        #return redirect(url_for(request.url))
    
    return render_template("home.html", user=current_user)












@views.route('/download')
@login_required
def download():
    
    all_data= Note.query.filter_by(user_id=current_user.id).all()

    with open(f'website/static/data/{current_user.id}.csv',"w+") as f:
        for data in all_data:
            row = f"{data.title}, {data.author},{data.department_teacher},{data.journal},{data.publication_year},{data.link},{data.h_index},{data.file}"
            f.write(row)  
            f.write("\n")
    
    return render_template("download.html", link=f'website//static//data//{current_user.id}.csv')





@views.route('/delete-note', methods=['POST'])
def delete_note():
    note = json.loads(request.data)
    noteId = note['noteId']
    note = Note.query.get(noteId)
    if note:
        if note.user_id == current_user.id:
            db.session.delete(note)
            db.session.commit()

    return jsonify({})